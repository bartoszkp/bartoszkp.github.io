﻿namespace DotRLGlueCodec.TaskSpec
{
    public interface ITaskSpecStringEncoder
    {
        string Encode(TaskSpecBase taskSpec);
    }
}
